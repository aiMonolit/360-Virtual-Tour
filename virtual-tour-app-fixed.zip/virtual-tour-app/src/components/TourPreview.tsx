import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Map } from 'lucide-react';
import { supabase, FloorPlan, Waypoint, PanoramaImage } from '../lib/supabase';
import 'pannellum/build/pannellum.css';

// Declare pannellum global
declare global {
  interface Window {
    pannellum: any;
  }
}

interface TourPreviewProps {
  tourId: string;
  onBack: () => void;
}

export default function TourPreview({ tourId, onBack }: TourPreviewProps) {
  const viewerRef = useRef<HTMLDivElement>(null);
  const [floorPlan, setFloorPlan] = useState<FloorPlan | null>(null);
  const [waypoints, setWaypoints] = useState<Waypoint[]>([]);
  const [panoramas, setPanoramas] = useState<PanoramaImage[]>([]);
  const [currentWaypoint, setCurrentWaypoint] = useState<Waypoint | null>(null);
  const [viewer, setViewer] = useState<any>(null);
  const [showMap, setShowMap] = useState(true);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTourData();
  }, [tourId]);

  useEffect(() => {
    // Load Pannellum script
    const script = document.createElement('script');
    script.src = 'https://cdn.pannellum.org/2.5/pannellum.js';
    script.async = true;
    script.onload = () => {
      if (currentWaypoint && panoramas.length > 0) {
        initializeViewer();
      }
    };
    document.body.appendChild(script);

    return () => {
      if (viewer) {
        viewer.destroy();
      }
      document.body.removeChild(script);
    };
  }, []);

  useEffect(() => {
    if (waypoints.length > 0 && panoramas.length > 0 && !currentWaypoint) {
      // Find first waypoint with a panorama
      const firstWaypoint = waypoints.find(w =>
        panoramas.some(p => p.waypoint_id === w.id)
      );
      if (firstWaypoint) {
        setCurrentWaypoint(firstWaypoint);
      }
    }
  }, [waypoints, panoramas]);

  useEffect(() => {
    if (currentWaypoint && window.pannellum && viewerRef.current) {
      initializeViewer();
    }
  }, [currentWaypoint]);

  const loadTourData = async () => {
    setLoading(true);
    try {
      // Load floor plan
      const { data: fpData, error: fpError } = await supabase
        .from('floor_plans')
        .select('*')
        .eq('tour_id', tourId)
        .maybeSingle();

      if (fpError) throw fpError;
      if (fpData) setFloorPlan(fpData);

      // Load waypoints
      if (fpData) {
        const { data: wpData, error: wpError } = await supabase
          .from('waypoints')
          .select('*')
          .eq('floor_plan_id', fpData.id)
          .order('created_at', { ascending: true });

        if (wpError) throw wpError;
        setWaypoints(wpData || []);
      }

      // Load panoramas
      const { data: panoData, error: panoError } = await supabase
        .from('panorama_images')
        .select('*')
        .order('created_at', { ascending: true });

      if (panoError) throw panoError;
      setPanoramas(panoData || []);
    } catch (error) {
      console.error('Error loading tour data:', error);
    } finally {
      setLoading(false);
    }
  };

  const initializeViewer = () => {
    if (!window.pannellum || !viewerRef.current || !currentWaypoint) return;

    const panorama = panoramas.find(p => p.waypoint_id === currentWaypoint.id);
    if (!panorama) return;

    // Destroy existing viewer
    if (viewer) {
      try {
        viewer.destroy();
      } catch (e) {
        // Ignore errors
      }
    }

    // Create hotspots for connected waypoints
    const hotspots = waypoints
      .filter(w => w.id !== currentWaypoint.id && panoramas.some(p => p.waypoint_id === w.id))
      .map(w => ({
        pitch: 0,
        yaw: Math.random() * 360 - 180, // Random positioning
        type: 'scene' as const,
        text: w.label || 'Navigate',
        sceneId: w.id,
      }));

    // Initialize Pannellum
    const newViewer = window.pannellum.viewer(viewerRef.current, {
      type: 'equirectangular',
      panorama: panorama.image_url,
      autoLoad: true,
      hotSpots: hotspots,
      hotSpotDebug: false,
      showControls: true,
      showFullscreenCtrl: true,
      showZoomCtrl: true,
      mouseZoom: true,
      orientationOnByDefault: false,
      draggable: true,
      friction: 0.15,
    });

    // Handle hotspot clicks
    hotspots.forEach((hotspot: any) => {
      newViewer.on('hotspot', (hotspotId: string) => {
        const targetWaypoint = waypoints.find(w => w.id === hotspot.sceneId);
        if (targetWaypoint) {
          setCurrentWaypoint(targetWaypoint);
        }
      });
    });

    setViewer(newViewer);
  };

  const navigateToWaypoint = (waypoint: Waypoint) => {
    if (panoramas.some(p => p.waypoint_id === waypoint.id)) {
      setCurrentWaypoint(waypoint);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="glass-card p-8 rounded-card">
          <div className="animate-pulse text-text-secondary">Loading tour...</div>
        </div>
      </div>
    );
  }

  if (waypoints.length === 0 || panoramas.length === 0) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="glass-card p-12 rounded-card text-center max-w-md">
          <h3 className="text-xl font-medium text-text-primary mb-4">
            Tour not ready for preview
          </h3>
          <p className="text-text-secondary mb-6">
            Please add waypoints and assign 360° images in the editor before previewing
          </p>
          <button
            onClick={onBack}
            className="bg-primary-500 text-white px-6 py-2 rounded-button hover:bg-primary-600 transition-all duration-standard"
          >
            Back to Editor
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-[calc(100vh-64px)]">
      {/* 360° Viewer */}
      <div ref={viewerRef} className="w-full h-full" />

      {/* Back Button */}
      <button
        onClick={onBack}
        className="fixed top-20 left-4 glass-button px-4 py-2 rounded-button text-text-primary hover:bg-glass-emphasized transition-all duration-standard z-10"
      >
        <ArrowLeft className="w-5 h-5 inline mr-2" />
        Back
      </button>

      {/* Scene Info */}
      {currentWaypoint && (
        <div className="fixed top-20 right-4 glass-card p-4 rounded-card max-w-xs z-10">
          <h3 className="text-lg font-medium text-text-primary">
            {currentWaypoint.label}
          </h3>
          <p className="text-sm text-text-secondary mt-1">
            Click hotspots to navigate
          </p>
        </div>
      )}

      {/* Mini Floor Plan */}
      {floorPlan && showMap && (
        <div className="fixed bottom-4 left-4 glass-card p-3 rounded-component z-10 w-64">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-text-primary">Floor Plan</span>
            <button
              onClick={() => setShowMap(false)}
              className="text-text-secondary hover:text-text-primary"
            >
              <Map className="w-4 h-4" />
            </button>
          </div>
          <div className="relative">
            <img
              src={floorPlan.image_url}
              alt="Floor plan"
              className="w-full h-auto rounded"
            />
            {/* Current position indicator */}
            {currentWaypoint && (
              <div
                className="absolute w-3 h-3 bg-primary-500 rounded-full animate-pulse"
                style={{
                  left: `${(currentWaypoint.x / (floorPlan.width || 1)) * 100}%`,
                  top: `${(currentWaypoint.y / (floorPlan.height || 1)) * 100}%`,
                  transform: 'translate(-50%, -50%)',
                }}
              />
            )}
          </div>
        </div>
      )}

      {!showMap && (
        <button
          onClick={() => setShowMap(true)}
          className="fixed bottom-4 left-4 glass-button p-3 rounded-button text-text-primary hover:bg-glass-emphasized transition-all duration-standard z-10"
        >
          <Map className="w-5 h-5" />
        </button>
      )}

      {/* Navigation Controls */}
      <div className="fixed bottom-4 right-4 glass-card p-3 rounded-component z-10 max-w-xs">
        <p className="text-sm font-medium text-text-primary mb-2">Waypoints</p>
        <div className="space-y-1">
          {waypoints
            .filter(w => panoramas.some(p => p.waypoint_id === w.id))
            .map(waypoint => (
              <button
                key={waypoint.id}
                onClick={() => navigateToWaypoint(waypoint)}
                className={`w-full text-left px-3 py-2 rounded text-sm transition-all ${
                  currentWaypoint?.id === waypoint.id
                    ? 'bg-primary-500 text-white'
                    : 'glass-subtle text-text-primary hover:bg-glass-emphasized'
                }`}
              >
                {waypoint.label}
              </button>
            ))}
        </div>
      </div>
    </div>
  );
}
