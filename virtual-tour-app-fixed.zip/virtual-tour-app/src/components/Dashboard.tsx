import { Eye, Edit, Clock } from 'lucide-react';
import { Tour } from '../lib/supabase';

interface DashboardProps {
  tours: Tour[];
  loading: boolean;
  onOpenTour: (tourId: string) => void;
  onPreviewTour: (tourId: string) => void;
  onCreateTour: () => void;
}

export default function Dashboard({ tours, loading, onOpenTour, onPreviewTour, onCreateTour }: DashboardProps) {
  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-64px)]">
        <div className="glass-card p-8 rounded-card">
          <div className="animate-pulse text-text-secondary">Loading tours...</div>
        </div>
      </div>
    );
  }

  if (tours.length === 0) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-64px)]">
        <div className="glass-card p-12 rounded-card max-w-md text-center">
          <h2 className="text-subtitle font-semibold text-text-primary mb-4">
            Create your first virtual tour
          </h2>
          <p className="text-text-secondary mb-8">
            Upload floor plans, place waypoints, and assign 360° images to create immersive experiences
          </p>
          <button
            onClick={onCreateTour}
            className="bg-primary-500 text-white px-8 py-3 rounded-button hover:bg-primary-600 transition-all duration-standard shadow-button"
          >
            Get Started
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="text-title font-semibold text-text-primary mb-8">Your Tours</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tours.map((tour) => (
          <div
            key={tour.id}
            className="glass-card p-6 rounded-card hover:shadow-glass-float transition-all duration-standard group"
          >
            {/* Thumbnail */}
            <div className="w-full h-48 bg-glass-subtle rounded-component mb-4 flex items-center justify-center overflow-hidden">
              {tour.thumbnail_url ? (
                <img src={tour.thumbnail_url} alt={tour.name} className="w-full h-full object-cover" />
              ) : (
                <div className="text-text-secondary">No preview</div>
              )}
            </div>

            {/* Info */}
            <h3 className="text-xl font-medium text-text-primary mb-2">{tour.name}</h3>
            <p className="text-sm text-text-secondary mb-4 line-clamp-2">
              {tour.description || 'No description'}
            </p>

            {/* Meta */}
            <div className="flex items-center text-xs text-text-secondary mb-4">
              <Clock className="w-4 h-4 mr-1" />
              {new Date(tour.updated_at).toLocaleDateString()}
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <button
                onClick={() => onOpenTour(tour.id)}
                className="flex-1 glass-button px-4 py-2 rounded-button text-text-primary hover:bg-glass-emphasized transition-all duration-standard"
              >
                <Edit className="w-4 h-4 inline mr-2" />
                Edit
              </button>
              <button
                onClick={() => onPreviewTour(tour.id)}
                className="flex-1 bg-primary-500 text-white px-4 py-2 rounded-button hover:bg-primary-600 transition-all duration-standard"
              >
                <Eye className="w-4 h-4 inline mr-2" />
                Preview
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
