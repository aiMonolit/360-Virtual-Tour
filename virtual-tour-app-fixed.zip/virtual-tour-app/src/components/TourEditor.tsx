import { useState, useEffect, useRef } from 'react';
import { Stage, Layer, Image as KonvaImage, Circle, Text as KonvaText } from 'react-konva';
import { Upload, MapPin, Image as ImageIcon, Save, Eye, Plus, Trash2 } from 'lucide-react';
import { supabase, FloorPlan, Waypoint, PanoramaImage } from '../lib/supabase';
import Konva from 'konva';

interface TourEditorProps {
  tourId: string;
  onBack: () => void;
  onPreview: () => void;
}

export default function TourEditor({ tourId, onBack, onPreview }: TourEditorProps) {
  const [floorPlan, setFloorPlan] = useState<FloorPlan | null>(null);
  const [floorPlanImage, setFloorPlanImage] = useState<HTMLImageElement | null>(null);
  const [waypoints, setWaypoints] = useState<Waypoint[]>([]);
  const [panoramas, setPanoramas] = useState<PanoramaImage[]>([]);
  const [selectedWaypoint, setSelectedWaypoint] = useState<string | null>(null);
  const [uploadingFloorPlan, setUploadingFloorPlan] = useState(false);
  const [uploadingPanorama, setUploadingPanorama] = useState(false);
  const [canvasSize, setCanvasSize] = useState({ width: 1200, height: 700 });
  
  const stageRef = useRef<Konva.Stage>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const panoramaInputRef = useRef<HTMLInputElement>(null);

  // Load floor plan and waypoints
  useEffect(() => {
    loadFloorPlan();
    loadWaypoints();
    loadPanoramas();
  }, [tourId]);

  // Load floor plan image when URL changes
  useEffect(() => {
    if (floorPlan?.image_url) {
      const img = new window.Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        setFloorPlanImage(img);
        // Adjust canvas size to fit image
        const maxWidth = window.innerWidth - 400;
        const maxHeight = window.innerHeight - 200;
        const scale = Math.min(maxWidth / img.width, maxHeight / img.height, 1);
        setCanvasSize({
          width: img.width * scale,
          height: img.height * scale,
        });
      };
      img.src = floorPlan.image_url;
    }
  }, [floorPlan]);

  const loadFloorPlan = async () => {
    try {
      const { data, error } = await supabase
        .from('floor_plans')
        .select('*')
        .eq('tour_id', tourId)
        .maybeSingle();

      if (error) throw error;
      if (data) setFloorPlan(data);
    } catch (error) {
      console.error('Error loading floor plan:', error);
    }
  };

  const loadWaypoints = async () => {
    if (!floorPlan) return;
    
    try {
      const { data, error } = await supabase
        .from('waypoints')
        .select('*')
        .eq('floor_plan_id', floorPlan.id)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setWaypoints(data || []);
    } catch (error) {
      console.error('Error loading waypoints:', error);
    }
  };

  const loadPanoramas = async () => {
    try {
      const { data, error } = await supabase
        .from('panorama_images')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) throw error;
      setPanoramas(data || []);
    } catch (error) {
      console.error('Error loading panoramas:', error);
    }
  };

  useEffect(() => {
    if (floorPlan) {
      loadWaypoints();
    }
  }, [floorPlan]);

  const handleFloorPlanUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingFloorPlan(true);
    try {
      // Convert to base64
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Data = reader.result as string;

        // Upload via Edge Function
        const { data, error } = await supabase.functions.invoke('upload-floor-plan', {
          body: { imageData: base64Data, fileName: file.name },
        });

        if (error) throw error;

        // Create floor plan record
        const { data: fpData, error: fpError } = await supabase
          .from('floor_plans')
          .insert({
            tour_id: tourId,
            image_url: data.data.publicUrl,
            width: canvasSize.width,
            height: canvasSize.height,
          })
          .select()
          .maybeSingle();

        if (fpError) throw fpError;
        setFloorPlan(fpData);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading floor plan:', error);
      alert('Failed to upload floor plan');
    } finally {
      setUploadingFloorPlan(false);
    }
  };

  const handleCanvasClick = async (e: any) => {
    if (!floorPlan) return;

    const stage = e.target.getStage();
    const pointerPosition = stage.getPointerPosition();
    
    // Add new waypoint
    try {
      const { data, error } = await supabase
        .from('waypoints')
        .insert({
          floor_plan_id: floorPlan.id,
          x: pointerPosition.x,
          y: pointerPosition.y,
          label: `Waypoint ${waypoints.length + 1}`,
        })
        .select()
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setWaypoints([...waypoints, data]);
      }
    } catch (error) {
      console.error('Error creating waypoint:', error);
    }
  };

  const handleWaypointDrag = async (waypointId: string, newX: number, newY: number) => {
    try {
      const { error } = await supabase
        .from('waypoints')
        .update({ x: newX, y: newY })
        .eq('id', waypointId);

      if (error) throw error;

      setWaypoints(waypoints.map(w =>
        w.id === waypointId ? { ...w, x: newX, y: newY } : w
      ));
    } catch (error) {
      console.error('Error updating waypoint:', error);
    }
  };

  const handlePanoramaUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingPanorama(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Data = reader.result as string;

        const { data, error } = await supabase.functions.invoke('upload-panorama', {
          body: { imageData: base64Data, fileName: file.name },
        });

        if (error) throw error;

        // Create panorama record
        const { data: panoData, error: panoError } = await supabase
          .from('panorama_images')
          .insert({
            waypoint_id: selectedWaypoint,
            image_url: data.data.publicUrl,
            filename: file.name,
          })
          .select()
          .maybeSingle();

        if (panoError) throw panoError;
        if (panoData) {
          setPanoramas([...panoramas, panoData]);
        }
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error('Error uploading panorama:', error);
      alert('Failed to upload panorama');
    } finally {
      setUploadingPanorama(false);
    }
  };

  const assignPanoramaToWaypoint = async (panoramaId: string, waypointId: string) => {
    try {
      const { error } = await supabase
        .from('panorama_images')
        .update({ waypoint_id: waypointId })
        .eq('id', panoramaId);

      if (error) throw error;

      setPanoramas(panoramas.map(p =>
        p.id === panoramaId ? { ...p, waypoint_id: waypointId } : p
      ));
    } catch (error) {
      console.error('Error assigning panorama:', error);
    }
  };

  const deleteWaypoint = async (waypointId: string) => {
    try {
      const { error } = await supabase
        .from('waypoints')
        .delete()
        .eq('id', waypointId);

      if (error) throw error;
      setWaypoints(waypoints.filter(w => w.id !== waypointId));
      if (selectedWaypoint === waypointId) {
        setSelectedWaypoint(null);
      }
    } catch (error) {
      console.error('Error deleting waypoint:', error);
    }
  };

  const getWaypointColor = (waypoint: Waypoint) => {
    const hasImage = panoramas.some(p => p.waypoint_id === waypoint.id);
    return hasImage ? '#34C759' : '#FF9500'; // green if has image, orange if not
  };

  return (
    <div className="flex h-[calc(100vh-64px)]">
      {/* Left Sidebar - Tools */}
      <div className="w-80 glass-card m-4 rounded-card p-6 overflow-y-auto">
        <h2 className="text-xl font-semibold text-text-primary mb-6">Tour Editor</h2>

        {/* Floor Plan Section */}
        <div className="mb-6">
          <h3 className="text-lg font-medium text-text-primary mb-3">Floor Plan</h3>
          {!floorPlan ? (
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFloorPlanUpload}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadingFloorPlan}
                className="w-full glass-button px-4 py-3 rounded-button text-text-primary hover:bg-glass-emphasized transition-all duration-standard"
              >
                <Upload className="w-5 h-5 inline mr-2" />
                {uploadingFloorPlan ? 'Uploading...' : 'Upload Floor Plan'}
              </button>
            </div>
          ) : (
            <div className="glass-subtle p-3 rounded-component">
              <p className="text-sm text-text-secondary">Floor plan loaded</p>
            </div>
          )}
        </div>

        {/* Waypoints Section */}
        {floorPlan && (
          <div className="mb-6">
            <h3 className="text-lg font-medium text-text-primary mb-3">
              Waypoints ({waypoints.length})
            </h3>
            <p className="text-sm text-text-secondary mb-3">
              Click on the floor plan to add waypoints
            </p>
            <div className="space-y-2">
              {waypoints.map((waypoint) => {
                const hasImage = panoramas.some(p => p.waypoint_id === waypoint.id);
                return (
                  <div
                    key={waypoint.id}
                    className={`glass-subtle p-3 rounded-component cursor-pointer hover:bg-glass-emphasized transition-all ${
                      selectedWaypoint === waypoint.id ? 'ring-2 ring-primary-500' : ''
                    }`}
                    onClick={() => setSelectedWaypoint(waypoint.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" style={{ color: getWaypointColor(waypoint) }} />
                        <span className="text-sm text-text-primary">{waypoint.label}</span>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteWaypoint(waypoint.id);
                        }}
                        className="text-semantic-error hover:bg-semantic-error/10 p-1 rounded"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    {!hasImage && (
                      <p className="text-xs text-text-secondary mt-1">No 360° image assigned</p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Panoramas Section */}
        {floorPlan && (
          <div className="mb-6">
            <h3 className="text-lg font-medium text-text-primary mb-3">
              360° Images ({panoramas.length})
            </h3>
            <input
              ref={panoramaInputRef}
              type="file"
              accept="image/*"
              onChange={handlePanoramaUpload}
              className="hidden"
            />
            <button
              onClick={() => panoramaInputRef.current?.click()}
              disabled={uploadingPanorama}
              className="w-full glass-button px-4 py-2 rounded-button text-text-primary hover:bg-glass-emphasized transition-all duration-standard mb-3"
            >
              <ImageIcon className="w-4 h-4 inline mr-2" />
              {uploadingPanorama ? 'Uploading...' : 'Upload 360° Image'}
            </button>

            <div className="space-y-2">
              {panoramas.map((panorama) => (
                <div
                  key={panorama.id}
                  className="glass-subtle p-3 rounded-component"
                >
                  <p className="text-sm text-text-primary mb-2">{panorama.filename}</p>
                  {selectedWaypoint && (
                    <button
                      onClick={() => assignPanoramaToWaypoint(panorama.id, selectedWaypoint)}
                      className="text-xs bg-primary-500 text-white px-3 py-1 rounded"
                    >
                      Assign to selected waypoint
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="space-y-3">
          <button
            onClick={onPreview}
            disabled={waypoints.length === 0}
            className="w-full bg-primary-500 text-white px-4 py-2 rounded-button hover:bg-primary-600 transition-all duration-standard disabled:opacity-50"
          >
            <Eye className="w-4 h-4 inline mr-2" />
            Preview Tour
          </button>
        </div>
      </div>

      {/* Canvas Area */}
      <div className="flex-1 flex items-center justify-center p-4">
        {!floorPlan ? (
          <div className="glass-card p-12 rounded-card text-center">
            <Upload className="w-16 h-16 text-text-secondary mx-auto mb-4" />
            <h3 className="text-xl font-medium text-text-primary mb-2">
              Upload a floor plan to get started
            </h3>
            <p className="text-text-secondary">
              Click the "Upload Floor Plan" button to begin creating your virtual tour
            </p>
          </div>
        ) : (
          <div className="glass-card p-4 rounded-card">
            <Stage
              ref={stageRef}
              width={canvasSize.width}
              height={canvasSize.height}
              onClick={handleCanvasClick}
            >
              <Layer>
                {floorPlanImage && (
                  <KonvaImage
                    image={floorPlanImage}
                    width={canvasSize.width}
                    height={canvasSize.height}
                  />
                )}
                
                {waypoints.map((waypoint) => (
                  <Circle
                    key={waypoint.id}
                    x={waypoint.x}
                    y={waypoint.y}
                    radius={16}
                    fill="rgba(255, 255, 255, 0.3)"
                    stroke={getWaypointColor(waypoint)}
                    strokeWidth={2}
                    shadowColor={getWaypointColor(waypoint)}
                    shadowBlur={12}
                    draggable
                    onDragEnd={(e) => {
                      handleWaypointDrag(waypoint.id, e.target.x(), e.target.y());
                    }}
                    onClick={(e) => {
                      e.cancelBubble = true;
                      setSelectedWaypoint(waypoint.id);
                    }}
                  />
                ))}
              </Layer>
            </Stage>
          </div>
        )}
      </div>
    </div>
  );
}
