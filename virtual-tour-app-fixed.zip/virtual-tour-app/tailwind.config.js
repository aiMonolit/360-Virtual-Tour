/** @type {import('tailwindcss').Config} */
module.exports = {
	darkMode: ['class'],
	content: [
		'./pages/**/*.{ts,tsx}',
		'./components/**/*.{ts,tsx}',
		'./app/**/*.{ts,tsx}',
		'./src/**/*.{ts,tsx}',
	],
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px',
			},
		},
		extend: {
			colors: {
				// Glassmorphism design tokens
				primary: {
					50: '#E5F2FF',
					100: '#CCE5FF',
					500: '#007AFF', // iOS Blue
					600: '#0051D5',
					900: '#003D99',
				},
				text: {
					primary: '#1D1D1F',
					secondary: '#86868B',
					'on-accent': '#FFFFFF',
				},
				glass: {
					bg: 'rgba(255, 255, 255, 0.2)',
					emphasized: 'rgba(255, 255, 255, 0.4)',
					subtle: 'rgba(255, 255, 255, 0.1)',
					border: 'rgba(255, 255, 255, 0.3)',
					'border-hover': 'rgba(255, 255, 255, 0.4)',
				},
				semantic: {
					success: '#34C759',
					warning: '#FF9500',
					error: '#FF3B30',
					info: '#5AC8FA',
				},
			},
			fontFamily: {
				poppins: ['Poppins', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
			},
			fontSize: {
				hero: ['64px', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
				title: ['48px', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
				subtitle: ['32px', { lineHeight: '1.3' }],
				'body-large': ['20px', { lineHeight: '1.6' }],
			},
			spacing: {
				xs: '8px',
				sm: '16px',
				md: '24px',
				lg: '32px',
				xl: '48px',
				'2xl': '64px',
				'3xl': '96px',
			},
			borderRadius: {
				button: '12px',
				card: '24px',
				modal: '28px',
				component: '16px',
			},
			backdropBlur: {
				glass: '15px',
				'glass-emphasized': '20px',
				'glass-strong': '40px',
			},
			boxShadow: {
				'glass-card': '0 8px 32px rgba(0, 0, 0, 0.08), 0 4px 16px rgba(0, 0, 0, 0.05)',
				'glass-float': '0 12px 40px rgba(0, 0, 0, 0.1), 0 6px 20px rgba(0, 0, 0, 0.08)',
				button: '0 4px 12px rgba(0, 122, 255, 0.3)',
			},
			transitionDuration: {
				fast: '200ms',
				standard: '300ms',
				smooth: '400ms',
			},
			backgroundImage: {
				'gradient-page': 'linear-gradient(135deg, #E8EAF0 0%, #F4F5F9 50%, #FAFBFF 100%)',
			},
			keyframes: {
				'accordion-down': {
					from: { height: 0 },
					to: { height: 'var(--radix-accordion-content-height)' },
				},
				'accordion-up': {
					from: { height: 'var(--radix-accordion-content-height)' },
					to: { height: 0 },
				},
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
			},
		},
	},
	plugins: [require('tailwindcss-animate')],
}