import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://shoztzisqewotmavkude.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNob3p0emlzcWV3b3RtYXZrdWRlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE3MjgyMDQsImV4cCI6MjA3NzMwNDIwNH0.HMK7AicZkGS7bns0Gqg6z5xyp8pyDzWfgJAZXzGSoAA';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Tour {
  id: string;
  name: string;
  description: string | null;
  thumbnail_url: string | null;
  user_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface FloorPlan {
  id: string;
  tour_id: string;
  image_url: string;
  width: number | null;
  height: number | null;
  created_at: string;
}

export interface Waypoint {
  id: string;
  floor_plan_id: string;
  x: number;
  y: number;
  label: string | null;
  created_at: string;
  updated_at: string;
}

export interface PanoramaImage {
  id: string;
  waypoint_id: string | null;
  image_url: string;
  filename: string | null;
  width: number | null;
  height: number | null;
  created_at: string;
}
