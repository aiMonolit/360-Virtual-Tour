import { useState, useEffect } from 'react';
import { Globe, Plus, FolderOpen } from 'lucide-react';
import { supabase, Tour } from './lib/supabase';
import Dashboard from './components/Dashboard';
import TourEditor from './components/TourEditor';
import TourPreview from './components/TourPreview';

type AppMode = 'dashboard' | 'editor' | 'preview';

interface AppState {
  mode: AppMode;
  selectedTourId: string | null;
}

function App() {
  const [state, setState] = useState<AppState>({
    mode: 'dashboard',
    selectedTourId: null,
  });

  const [tours, setTours] = useState<Tour[]>([]);
  const [loading, setLoading] = useState(true);

  // Load tours on mount
  useEffect(() => {
    loadTours();
  }, []);

  const loadTours = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tours')
        .select('*')
        .order('updated_at', { ascending: false });

      if (error) throw error;
      setTours(data || []);
    } catch (error) {
      console.error('Error loading tours:', error);
    } finally {
      setLoading(false);
    }
  };

  const createNewTour = async () => {
    try {
      const { data, error } = await supabase
        .from('tours')
        .insert({
          name: `Tour ${tours.length + 1}`,
          description: 'New virtual tour',
        })
        .select()
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setTours([data, ...tours]);
        setState({ mode: 'editor', selectedTourId: data.id });
      }
    } catch (error) {
      console.error('Error creating tour:', error);
    }
  };

  const openTourEditor = (tourId: string) => {
    setState({ mode: 'editor', selectedTourId: tourId });
  };

  const openTourPreview = (tourId: string) => {
    setState({ mode: 'preview', selectedTourId: tourId });
  };

  const backToDashboard = () => {
    setState({ mode: 'dashboard', selectedTourId: null });
    loadTours();
  };

  return (
    <div className="min-h-screen">
      {/* Glass Navigation Bar */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-nav h-16">
        <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Globe className="w-8 h-8 text-primary-500" />
            <span className="text-xl font-semibold text-text-primary">TourBuilder</span>
          </div>
          
          <div className="flex items-center gap-4">
            {state.mode !== 'dashboard' && (
              <button
                onClick={backToDashboard}
                className="glass-button px-4 py-2 rounded-button text-text-primary hover:bg-glass-emphasized transition-all duration-standard"
              >
                <FolderOpen className="w-5 h-5 inline mr-2" />
                Projects
              </button>
            )}
            {state.mode === 'dashboard' && (
              <button
                onClick={createNewTour}
                className="bg-primary-500 text-white px-6 py-2 rounded-button hover:bg-primary-600 transition-all duration-standard shadow-button"
              >
                <Plus className="w-5 h-5 inline mr-2" />
                New Tour
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-16">
        {state.mode === 'dashboard' && (
          <Dashboard
            tours={tours}
            loading={loading}
            onOpenTour={openTourEditor}
            onPreviewTour={openTourPreview}
            onCreateTour={createNewTour}
          />
        )}

        {state.mode === 'editor' && state.selectedTourId && (
          <TourEditor
            tourId={state.selectedTourId}
            onBack={backToDashboard}
            onPreview={() => openTourPreview(state.selectedTourId!)}
          />
        )}

        {state.mode === 'preview' && state.selectedTourId && (
          <TourPreview
            tourId={state.selectedTourId}
            onBack={backToDashboard}
          />
        )}
      </main>
    </div>
  );
}

export default App;
